package com.example.authors

import android.app.FragmentManager
import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast


class SignupFragment : Fragment() {


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_signup, container, false)
        val botn : Button = view.findViewById(R.id.logn)
        botn.setOnClickListener{

            val fragment = loginFragment()
            val transaction = fragmentManager?.beginTransaction()
            transaction?.replace(R.id.signupFragment,fragment)?.commit()



            val sharedPreferences = requireActivity().getSharedPreferences("MyAppPreferences", Context.MODE_PRIVATE)
            val firstNameEditText =view.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.fname)
            val lastNameEditText = view.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.lname)
            val phoneNumberEditText = view.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.phnum)
            val passwordEditText = view.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.password)
            val buttonMale = view.findViewById<com.google.android.material.button.MaterialButton>(R.id.male)
            val buttonFemale = view.findViewById<com.google.android.material.button.MaterialButton>(R.id.female)

            var selectedGender: String? = null
            buttonMale.setOnClickListener {
                 selectedGender = "Male"
            }

            buttonFemale.setOnClickListener {
                 selectedGender = "Female"
            }
            val firstName = firstNameEditText.text.toString()
            val lastName = lastNameEditText.text.toString()
            val phoneNumber = phoneNumberEditText.text.toString()
            val formattedPhoneNumber = formatPhoneNumber(phoneNumber)
            val password = passwordEditText.text.toString()
            if (password.length < 8 || password.length > 16) {

                Toast.makeText(context, "Password must be between 8 and 16 characters", Toast.LENGTH_SHORT).show()

            }

            val editor = sharedPreferences.edit()

            editor.putString("firstName", firstName)
            editor.putString("lastName", lastName)
            editor.putString("phoneNumber", formattedPhoneNumber)
            editor.putString("password", password)
            editor.putString("gender", selectedGender)

            editor.apply()

        }

        return view
    }

}

fun formatPhoneNumber(phoneNumber: String): String {
    val pattern = "(\\d{3})(\\d{3})(\\d{4})".toRegex()
    return pattern.replace(phoneNumber, "($1) $2-$3")
}