package com.example.authors

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast

class loginFragment : Fragment() {

    @SuppressLint("CutPasteId")
    override fun onCreateView(


        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?

    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_login, container, false)
        val btn: Button = view.findViewById(R.id.sinup)
        btn.setOnClickListener {
            val fragment = SignupFragment()
            val transaction = fragmentManager?.beginTransaction()
            transaction?.replace(R.id.nav_continer, fragment)?.commit()
            val sharedPref = requireActivity().getSharedPreferences("MyPref", Context.MODE_PRIVATE)
            val editor = sharedPref.edit()

            val phoneNumberEditText =
                view.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.phone_text)
            val passwordEditText =
                view.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.pass_text)

            val loginButton = view.findViewById<Button>(R.id.logn)
            loginButton.setOnClickListener {
                val phoneNumber = phoneNumberEditText.text.toString()
                val password = passwordEditText.text.toString()


                if (password.length < 8 || password.length > 16) {

                    Toast.makeText(context, "Password must be between 8 and 16 characters", Toast.LENGTH_SHORT).show()

                    val editTextPhoneNumber = view.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.phone_text)
                    val editTextPassword = view.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.pass_text)
                    val inputPhoneNumber = editTextPhoneNumber.text.toString()
                    val inputPassword = editTextPassword.text.toString()


                    if (checkLoginCredentials(inputPhoneNumber, inputPassword)) {

                        Toast.makeText(requireContext(), "Login successful", Toast.LENGTH_SHORT).show()
                    } else {

                        Toast.makeText(requireContext(), "Login failed", Toast.LENGTH_SHORT).show()
                    }
                }

                    val editTextPhoneNumber = view.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.phone_text)
                    val editTextPassword = view.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.pass_text)
                editTextPhoneNumber.text.toString()
                editTextPassword.text.toString()


                editor.putString("phone_number", phoneNumber)
                editor.putString("password", password)
                editor.apply()
            }


        }


        return view
}
    private fun checkLoginCredentials(phoneNumber: String, password: String): Boolean {

        val sharedPreferences = requireActivity().getSharedPreferences("myPrefs", Context.MODE_PRIVATE)
        val savedPhoneNumber = sharedPreferences.getString("phoneNumber", "")
        val savedPassword = sharedPreferences.getString("password", "")

        return phoneNumber == savedPhoneNumber && password == savedPassword
    }



    }




